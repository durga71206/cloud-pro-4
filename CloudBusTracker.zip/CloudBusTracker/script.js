alert("JavaScript is working!");
import app from "./firebase-config.js";

import {
    getAuth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const auth = getAuth(app);


// LOGIN BUTTON
window.login = async function () {

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (email === "" || password === "") {
        alert("Please enter email and password");
        return;
    }

    try {

        await signInWithEmailAndPassword(auth, email, password);

        alert("Login successful!");

        window.location.href = "dashboard.html";

    } catch (error) {

        alert(error.message);

    }
};


// REGISTER BUTTON FROM LOGIN PAGE
window.register = function () {

    window.location.href = "register.html";

};


// CREATE ACCOUNT
window.createAccount = async function () {

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (name === "" || email === "" || password === "") {
        alert("Please fill all fields");
        return;
    }

    try {

        await createUserWithEmailAndPassword(
            auth,
            email,
            password
        );

        alert("Account created successfully!");

        window.location.href = "index.html";

    } catch (error) {

        alert(error.message);

    }

};


// BACK TO LOGIN
window.goToLogin = function () {

    window.location.href = "index.html";

};
function login() {
    alert("Login button working!");
}

function register() {
    window.location.href = "register.html";
}