import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

const firebaseConfig = {
    apiKey: "AIzaSyBShR6pXn8zjd8j_M9vc2LLtjh_j7x2-v0",
    authDomain: "cloudbustracker-e5a04.firebaseapp.com",
    projectId: "cloudbustracker-e5a04",
    storageBucket: "cloudbustracker-e5a04.firebasestorage.app",
    messagingSenderId: "639463842568",
    appId: "1:639463842568:web:d40bedda26a77e230682bd"
};

const app = initializeApp(firebaseConfig);

export default app;